import React from "react";
import { Icon, Label, Button, Rating, Transition } from "semantic-ui-react";
import logo from "../proscan.png";

const StepTwo = ({
  center,
  setCenter,
  scanCenters,
  locality,
  setLocality,
  cities,
  localities,
  setCurrentStep,
}) => {
  var sub;
  if (locality !== null) {
    scanCenters.map((center) => {
      if (center.Locality === locality) {
        sub = center.Center;
      }
    });
  }
  return (
    <div>
      <div>
        {locality === null ? (
          scanCenters.map((city) => {
            return (
              <Label
                image
                color="orange"
                size="large"
                onClick={() => setLocality(city.Locality)}
                style={{ cursor: "pointer", margin: 5 }}
              >
                {city.Locality}
              </Label>
            );
          })
        ) : (
          <Label image style={{ margin: 5 }}>
            {locality}
            <Icon name="delete" onClick={() => setLocality(null)} />
          </Label>
        )}
      </div>
      <div>
        {locality !== null && center === null
          ? sub.map((locality) => {
              return (
                <Label
                  image
                  color="orange"
                  size="large"
                  onClick={() => setCenter(locality)}
                  style={{ cursor: "pointer", margin: 5 }}
                >
                 <img src={logo} style={{ width: 150, height: 30 }} />
                  {locality}
                  <Rating icon='star' style={{ margin: 5 }} defaultRating={5} maxRating={5} />

                  <ul style={{"text-align": "left"}}>
                  <li style={{"margin-bottom": "3px"}}><span>Doctor on Call</span>
                  </li>
                  <li style={{"margin-bottom": "3px"}}><span>Free Wi-Fi</span>
                  </li>
                  <li style={{"margin-bottom": "3px"}}>
                    <span>Free Parking</span>
                  </li>
                  </ul>
                  <div style={{"text-align": "right"}}>Pricing: Rs.3000</div>

                </Label>
              );
            })
          : center !== null && (
              <Label image style={{ margin: 5 }}>
                {center}
                <Icon name="delete" onClick={() => setCenter(null)} />
              </Label>
            )}
      </div>
      <div>
        <Button
          icon
          labelPosition="left"
          style={{ marginTop: 50 }}
          onClick={() => setCurrentStep(1)}
        >
          Back
          <Icon name="left arrow" />
        </Button>
        {center !== null && locality !== null && (
          <Button
            icon
            labelPosition="right"
            color="orange"
            style={{ marginTop: 50 }}
            onClick={() => setCurrentStep(3)}
          >
            Next
            <Icon name="right arrow" />
          </Button>
        )}
      </div>
    </div>
  );
};

export default StepTwo;
