import React, { useState } from "react";
import {
    Form
  } from "semantic-ui-react";
import {DateTimeInput
  } from 'semantic-ui-calendar-react';
  import $ from 'jquery'; 
 export  default class DateTimeForm extends React.Component {
  constructor(props) {
    super(props);
 
    this.state = {
      date: '',
      time: '',
      dateTime: '',
      datesRange: ''
    };
  }

  componentDidMount() {
  
  }
 
  handleChange = (event, {name, value}) => {
   
    $('.ui.calendar')
    .calendar({
        popupOptions: {
             observeChanges: false
        }
    });
  }
 
  render() {
    return (
       
         <DateTimeInput
          name="dateTime"
          placeholder="Date Time"
          //alue={this.state.dateTime}
        // iconPosition="left"
        onChange={this.handleChange}
        />
    );
  }
}